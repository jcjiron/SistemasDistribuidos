/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadorarmi;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.rmi.AlreadyBoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author juan
 */
public class Server {


    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws RemoteException, AlreadyBoundException {
        
    /**
     *
     */
     String IP="localhost";
     String PUERTO = "5050";
     String REGISTRY_NAME = "MY_REGISTRY";
     String PAH_REGISTRY = IP+":"+PUERTO+"/"+REGISTRY_NAME;
    
         Remote keyRegOperaciones = UnicastRemoteObject.exportObject(new Operaciones() {
             @Override
             public int suma(int x, int y) throws RemoteException {
                 return 1;
             }

             @Override
             public int resta(int x, int y) throws RemoteException {
                 return 2;
             }

             @Override
             public int multiplicacion(int x, int y) throws RemoteException {
                 return 3;
             }

             @Override
             public int division(int x, int y) throws RemoteException {
                 return 4;
             }

             @Override
             public int otraCosa(int x, int y) throws RemoteException {
                 return 5;
             }

             @Override
             public int otraCosa2(int x, int y) throws RemoteException {
                 return 6;
             }
         }, 0);
         
         
     
     
            Registry registry = LocateRegistry.createRegistry(Registry.REGISTRY_PORT);
            registry.bind(PAH_REGISTRY, keyRegOperaciones);
            System.out.println("Serevr corriendo: "+PAH_REGISTRY);

        
    }
    
}
